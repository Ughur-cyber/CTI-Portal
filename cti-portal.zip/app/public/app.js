'use strict';
const $ = (s, r = document) => r.querySelector(s);
const esc = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const KINDS = { kev: 'KEV (aktiv istismar)', ransomware: 'Ransomware', news: 'Xəbər', phishing: 'Phishing', cve: 'CVE' };
const TIERS = { 1: 'Müştəri', 2: 'Azərbaycan', 3: 'Sektor' };
const SECTORS = ['Aviasiya', 'Dəmiryolu', 'Metro', 'Avtobus', 'Taksi', 'Dəniz/Liman', 'Poçt', 'Telekom', 'Logistika'];
const defang = (s) => String(s).replace(/^http/i, 'hxxp').replace(/\./g, '[.]');
const view = $('#view');

async function api(path, opt) {
  const r = await fetch(path, { cache: 'no-store', ...opt });
  const j = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(j.error || 'Xəta ' + r.status);
  return j;
}
function toast(t) { const el = $('#toast'); el.textContent = t; el.classList.add('show'); setTimeout(() => el.classList.remove('show'), 1600); }
function ago(v) {
  const s = (Date.now() - new Date(v).getTime()) / 1000;
  if (s < 90) return 'indicə';
  if (s < 3600) return Math.round(s / 60) + ' dəq əvvəl';
  if (s < 86400) return Math.round(s / 3600) + ' saat əvvəl';
  if (s < 86400 * 30) return Math.round(s / 86400) + ' gün əvvəl';
  return new Date(v).toLocaleDateString('az');
}
const fdate = (v) => new Date(v).toLocaleString('az', { dateStyle: 'medium', timeStyle: 'short' });
const kcolor = (k) => `var(--k-${['kev', 'ransomware', 'news', 'phishing', 'cve'].includes(k) ? k : 'news'})`;

function itemHtml(it) {
  const safeUrl = it.kind === 'phishing' ? null : it.url;
  const d = it.data || {};
  const rows = Object.entries(d).filter(([, v]) => v != null && v !== '' && !(Array.isArray(v) && !v.length));
  return `<li class="it" data-id="${it.id}" style="--c:${kcolor(it.kind)}"><span class="edge"></span><div>
    <div class="ttl">${esc(it.kind === 'phishing' ? defang(it.title) : it.title)}</div>
    <div class="meta">
      ${it.tier < 4 ? `<span class="tag tier t${it.tier}">${TIERS[it.tier]}</span>` : ''}
      <span>${esc(KINDS[it.kind] || it.kind)}</span>
      ${it.sector ? `<span class="tag">${esc(it.sector)}</span>` : ''}
      ${(it.matched_clients || []).map((c) => `<span class="tag">${esc(c)}</span>`).join('')}
      <span>${esc(it.source || '')}</span><span title="${esc(fdate(it.occurred_at))}">${ago(it.occurred_at)}</span>
    </div>
    <div class="detail">
      ${it.summary ? `<div class="desc">${esc(it.summary)}</div>` : ''}
      <dl>
        <dt>Tarix</dt><dd>${esc(fdate(it.occurred_at))}</dd>
        ${safeUrl ? `<dt>Keçid</dt><dd><a href="${esc(safeUrl)}" target="_blank" rel="noopener noreferrer">${esc(safeUrl)}</a></dd>` : it.url ? `<dt>Ünvan</dt><dd class="mono">${esc(defang(it.url))}</dd>` : ''}
        ${rows.map(([k, v]) => `<dt>${esc(k)}</dt><dd>${esc(Array.isArray(v) ? v.join(', ') : typeof v === 'object' ? JSON.stringify(v) : v)}</dd>`).join('')}
      </dl>
    </div></div></li>`;
}
function bindToggle(root) {
  root.addEventListener('click', (e) => { if (e.target.closest('a')) return; const li = e.target.closest('.it'); if (li) li.classList.toggle('open'); });
}
const emptyBox = (t) => `<div class="empty">${t}</div>`;

// ---------- Ümumi baxış ----------
async function pageOverview() {
  view.innerHTML = '<h1>Ümumi baxış</h1><p class="sub">Yüklənir…</p>';
  const o = await api('/api/overview');
  const cnt = Object.fromEntries(o.counts.map((c) => [c.kind, c]));
  const days = {}; o.daily.forEach((d) => { (days[d.d] = days[d.d] || {})[d.kind] = d.n; });
  const keys = []; for (let i = 29; i >= 0; i--) keys.push(new Date(Date.now() - i * 864e5).toISOString().slice(0, 10));
  const max = Math.max(1, ...keys.map((k) => Object.values(days[k] || {}).reduce((a, b) => a + b, 0)));
  const bars = keys.map((k) => `<div title="${k}">${Object.entries(days[k] || {}).map(([kind, n]) => `<span style="--c:${kcolor(kind)};height:${n / max * 76}px"></span>`).join('')}</div>`).join('');
  const smax = Math.max(1, ...o.sectors.map((s) => s.n));
  const nTier = o.alerts.filter((a) => a.tier === 1).length;
  view.innerHTML = `
    <h1>Sizə aid olanlar</h1>
    <p class="sub">Son 30 gün: müştərilərin adı, Azərbaycan və sektor (nəqliyyat, telekom, logistika) üzrə uyğunluqlar.${nTier ? ` <b>${nTier} müştəri uyğunluğu var.</b>` : ''}</p>
    <div class="grid2">
      <section class="card"><ul class="list" id="alerts">${o.alerts.length ? o.alerts.map(itemHtml).join('') : emptyBox('Hələ uyğun hadisə yoxdur. Mənbələr işlədikcə burada görünəcək. "Mənbələr" bölməsindən toplayıcıların vəziyyətinə baxın.')}</ul></section>
      <div>
        <div class="stats">
          ${['kev', 'ransomware', 'news'].map((k) => `<div><b>${(cnt[k] || { d7: 0 }).d7}</b><span>${esc(KINDS[k])}, son 7 gün</span></div>`).join('')}
          <div><b>${o.totals.actors}</b><span>Təhdid qrupu</span></div>
        </div>
        <section class="card"><h2>Son 30 gün hadisə sayı</h2><div class="days">${bars}</div>
          <div class="legend">${['kev', 'ransomware', 'news', 'phishing', 'cve'].map((k) => `<em style="--c:${kcolor(k)}">${esc(KINDS[k])}</em>`).join('')}</div></section>
        <section class="card"><h2>Ransomware qurbanları, sektor üzrə</h2>
          ${o.sectors.length ? o.sectors.map((s) => `<div class="hbar"><span>${esc(s.sector)}</span><i style="width:${s.n / smax * 100}%"></i><b>${s.n}</b></div>`).join('') : '<span class="muted">Məlumat yoxdur</span>'}</section>
      </div>
    </div>`;
  bindToggle($('#alerts'));
}

// ---------- Lent ----------
let feedState = { kind: '', sector: '', tier: '', days: '30', q: '', client: '', offset: 0 };
async function pageFeed() {
  const st = feedState;
  view.innerHTML = `<h1>Hadisə lenti</h1><p class="sub">Bütün mənbələrdən gələn hadisələr: zəifliklər, ransomware, xəbərlər, phishing.</p>
    <div class="bar" id="chips">${['', 'kev', 'ransomware', 'news', 'phishing', 'cve'].map((k) => `<button class="chip ${st.kind === k ? 'on' : ''}" data-k="${k}">${k ? esc(KINDS[k]) : 'Hamısı'}</button>`).join('')}</div>
    <div class="bar">
      <input id="q" type="search" placeholder="Axtar: ad, CVE, qrup, şirkət…" value="${esc(st.q)}" aria-label="Axtar">
      <select id="sector" aria-label="Sektor"><option value="">Bütün sektorlar</option>${SECTORS.map((s) => `<option ${st.sector === s ? 'selected' : ''}>${s}</option>`).join('')}</select>
      <select id="tier" aria-label="Uyğunluq"><option value="">Bütün hadisələr</option><option value="1" ${st.tier === '1' ? 'selected' : ''}>Yalnız müştəri</option><option value="2" ${st.tier === '2' ? 'selected' : ''}>Müştəri + Azərbaycan</option><option value="3" ${st.tier === '3' ? 'selected' : ''}>Bizə aid olanların hamısı</option></select>
      <select id="days" aria-label="Müddət">${[['1', '24 saat'], ['7', '7 gün'], ['30', '30 gün'], ['365', '1 il']].map(([v, t]) => `<option value="${v}" ${st.days === v ? 'selected' : ''}>${t}</option>`).join('')}</select>
      ${st.client ? `<button class="chip on" id="clr">Müştəri: ${esc(st.client)} ✕</button>` : ''}
    </div>
    <div class="muted" id="cnt"></div><section class="card"><ul class="list" id="rows"></ul></section>
    <p><button class="btn" id="more" hidden>Daha çox göstər</button></p>`;
  let rows = [];
  async function load(reset) {
    if (reset) { st.offset = 0; rows = []; }
    const sp = new URLSearchParams({ limit: 50, offset: st.offset });
    for (const k of ['kind', 'sector', 'tier', 'days', 'q', 'client']) if (st[k]) sp.set(k, st[k]);
    const r = await api('/api/items?' + sp);
    rows = rows.concat(r.rows);
    $('#rows').innerHTML = rows.length ? rows.map(itemHtml).join('') : emptyBox('Bu filtrlərə uyğun hadisə yoxdur. Filtrləri azaldın.');
    $('#cnt').textContent = `${r.total} nəticə`;
    $('#more').hidden = rows.length >= r.total;
  }
  $('#chips').onclick = (e) => { const b = e.target.closest('button'); if (b) { st.kind = b.dataset.k; pageFeed(); } };
  for (const id of ['sector', 'tier', 'days']) $('#' + id).onchange = (e) => { st[id] = e.target.value; load(true); };
  let t; $('#q').oninput = (e) => { clearTimeout(t); t = setTimeout(() => { st.q = e.target.value; load(true); }, 300); };
  if ($('#clr')) $('#clr').onclick = () => { st.client = ''; pageFeed(); };
  $('#more').onclick = () => { st.offset += 50; load(false); };
  bindToggle($('#rows'));
  await load(true);
}

// ---------- Qruplar və zərərli proqramlar ----------
async function pageEntities(kind) {
  const isActor = kind === 'actors';
  view.innerHTML = `<h1>${isActor ? 'Təhdid qrupları' : 'Zərərli proqramlar'}</h1><p class="sub">MITRE ATT&amp;CK məlumatı əsasında. Gündə bir dəfə yenilənir.</p>
    <div class="bar"><input id="q" type="search" placeholder="Ad və ya ləqəb üzrə axtar" aria-label="Axtar"></div>
    <div class="cols"><section class="card pick" id="pick"></section><section class="card" id="det"><div class="empty">Soldan seçin.</div></section></div>`;
  async function list() {
    const rows = await api(`/api/${kind}?q=` + encodeURIComponent($('#q').value));
    $('#pick').innerHTML = rows.length ? rows.map((r) => `<button data-id="${r.id}"><b>${esc(r.name)}</b><small>${esc((r.aliases || []).slice(0, 3).join(', ') || r.mitre_id || '')}${isActor ? ` · ${r.tech} texnika` : ` · ${r.groups} qrup`}</small></button>`).join('') : emptyBox('Heç nə tapılmadı.');
  }
  let t; $('#q').oninput = () => { clearTimeout(t); t = setTimeout(list, 250); };
  $('#pick').onclick = async (e) => {
    const b = e.target.closest('button'); if (!b) return;
    document.querySelectorAll('#pick button').forEach((x) => x.classList.toggle('on', x === b));
    const r = await api(`/api/${kind}/${b.dataset.id}`);
    const link = r.mitre_id ? `https://attack.mitre.org/${isActor ? 'groups' : 'software'}/${r.mitre_id}/` : null;
    let body = `<h2>${esc(r.name)}</h2><div class="meta">${r.mitre_id ? `<span class="tag">${esc(r.mitre_id)}</span>` : ''}${(r.aliases || []).map((a) => `<span class="tag">${esc(a)}</span>`).join('')}${link ? `<a href="${link}" target="_blank" rel="noopener noreferrer">MITRE səhifəsi</a>` : ''}</div>
      <p class="desc">${esc(r.description || 'Təsvir yoxdur.')}</p>`;
    if (isActor) {
      const by = {}; (r.techniques || []).forEach((x) => { (by[x.tactic || 'digər'] = by[x.tactic || 'digər'] || []).push(x); });
      body += `<div class="tac">İstifadə etdiyi proqramlar</div>${(r.software || []).map((s) => `<span class="tag tech">${esc(s)}</span>`).join('') || '<span class="muted">Məlumat yoxdur</span>'}`;
      body += Object.entries(by).map(([tac, arr]) => `<div class="tac">${esc(tac)}</div>${arr.map((x) => `<span class="tag tech" title="${esc(x.name)}"><span class="mono">${esc(x.id)}</span> ${esc(x.name)}</span>`).join('')}`).join('');
    } else {
      body += `<div class="tac">Tip</div>${esc(r.kind === 'tool' ? 'Alət' : 'Zərərli proqram')}${(r.platforms || []).length ? ' · ' + esc(r.platforms.join(', ')) : ''}<div class="tac">İstifadə edən qruplar</div>${(r.used_by || []).map((s) => `<span class="tag tech">${esc(s)}</span>`).join('') || '<span class="muted">Məlumat yoxdur</span>'}`;
    }
    $('#det').innerHTML = body;
  };
  await list();
}

// ---------- Müştərilər ----------
async function pageClients() {
  const rows = await api('/api/clients');
  view.innerHTML = `<h1>Müştərilər</h1><p class="sub">Hadisə mətnində bu adlardan biri keçəndə hadisə müştəriyə bağlanır. Sətirə basın, o müştəriyə aid hadisələr açılsın.</p>
    <section class="card"><table><thead><tr><th>Müştəri</th><th>Sektor</th><th>Son 30 gün</th><th>Cəmi</th><th>Axtarılan adlar</th></tr></thead><tbody>
    ${rows.map((c) => `<tr class="click" data-n="${esc(c.name)}"><td><b>${esc(c.name)}</b></td><td>${esc(c.sector || '')}</td><td>${c.d30 ? `<span class="tag tier t1">${c.d30}</span>` : '0'}</td><td>${c.total}</td><td class="muted">${esc((c.keywords || []).join(', '))}</td></tr>`).join('')}</tbody></table></section>`;
  view.querySelector('tbody').onclick = (e) => { const tr = e.target.closest('tr'); if (!tr) return; feedState = { kind: '', sector: '', tier: '', days: '365', q: '', client: tr.dataset.n, offset: 0 }; location.hash = '#/feed'; };
}

// ---------- Mənbələr ----------
async function pageSources() {
  const rows = await api('/api/sources');
  view.innerHTML = `<h1>Mənbələr</h1><p class="sub">Toplayıcıların vəziyyəti. Xəta olsa səbəbi burada görünür.</p>
    <section class="card"><table><thead><tr><th>Mənbə</th><th>Tezlik</th><th>Son işləmə</th><th>Vəziyyət</th><th>Yeni qeyd</th><th></th></tr></thead><tbody>
    ${rows.map((s) => `<tr><td>${esc(s.title)}${s.last_error ? `<div class="err">${esc(s.last_error)}</div>` : ''}</td><td>${s.interval_min} dəq</td><td>${s.last_run ? esc(ago(s.last_run)) : 'hələ işləməyib'}</td>
      <td class="${s.last_status === 'ok' ? 'ok' : s.last_status === 'error' ? 'err' : ''}">${s.run_requested ? 'növbədədir' : esc(s.last_status || '—')}</td><td>${s.last_count == null ? '' : s.last_count}</td>
      <td><button class="btn" data-k="${s.key}">İndi işlət</button></td></tr>`).join('')}</tbody></table></section>`;
  view.querySelector('tbody').onclick = async (e) => { const b = e.target.closest('button'); if (!b) return; await api(`/api/sources/${b.dataset.k}/run`, { method: 'POST' }); toast('Növbəyə qoyuldu, 20 saniyə ərzində başlayacaq'); setTimeout(pageSources, 1500); };
}

const ROUTES = { '': pageOverview, feed: pageFeed, actors: () => pageEntities('actors'), malware: () => pageEntities('malware'), clients: pageClients, sources: pageSources };
async function router() {
  const r = (location.hash.replace(/^#\/?/, '') || '').split('?')[0];
  document.querySelectorAll('#nav a').forEach((a) => a.classList.toggle('on', a.dataset.r === r));
  try { await (ROUTES[r] || pageOverview)(); } catch (e) { view.innerHTML = `<div class="banner">${esc(e.message)}</div>`; }
  window.scrollTo(0, 0);
}
window.addEventListener('hashchange', router);
router();
setInterval(() => { if (!location.hash || location.hash === '#/') router(); }, 120000);
