create table if not exists clients (
  id serial primary key,
  name text unique not null,
  sector text,
  keywords text[] not null default '{}'
);
create table if not exists sources (
  key text primary key,
  title text not null,
  interval_min int not null default 60,
  enabled bool not null default true,
  config jsonb not null default '{}',
  last_run timestamptz,
  last_status text,
  last_count int,
  last_error text,
  run_requested bool not null default false
);
create table if not exists items (
  id bigserial primary key,
  kind text not null,
  ext_id text not null,
  title text not null,
  summary text,
  occurred_at timestamptz not null default now(),
  source text,
  url text,
  sector text,
  severity text,
  tags text[] not null default '{}',
  matched_clients text[] not null default '{}',
  region_az bool not null default false,
  data jsonb not null default '{}',
  created_at timestamptz not null default now(),
  unique (kind, ext_id)
);
create index if not exists items_time on items (occurred_at desc);
create index if not exists items_kind_time on items (kind, occurred_at desc);
create table if not exists actors (
  id serial primary key,
  name text unique not null,
  mitre_id text,
  aliases text[] not null default '{}',
  description text,
  techniques jsonb not null default '[]',
  software text[] not null default '{}',
  updated_at timestamptz not null default now()
);
create table if not exists malware (
  id serial primary key,
  name text unique not null,
  mitre_id text,
  kind text,
  aliases text[] not null default '{}',
  description text,
  used_by text[] not null default '{}',
  platforms text[] not null default '{}',
  updated_at timestamptz not null default now()
);
