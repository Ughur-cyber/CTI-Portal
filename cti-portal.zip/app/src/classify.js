'use strict';
// Mətnə görə sektor, müştəri və Azərbaycan əlaqəsini təyin edir.

const SECTOR_PATTERNS = [
  ['Aviasiya', /\b(airlines?|airways|airports?|aviation|aerospace|aircraft|air traffic|aeroflot)\b/i],
  ['Dəmiryolu', /\b(railways?|railroads?|rail operator|train operator|locomotives?)\b/i],
  ['Metro', /\b(subway|metro system|metro operator|metropolitan transit|transit authority)\b/i],
  ['Avtobus', /\b(bus operator|bus company|coach company|public transport|transit agency)\b/i],
  ['Taksi', /\b(taxi|ride-hailing|ride-sharing|ridesharing|uber|lyft)\b/i],
  ['Dəniz/Liman', /\b(shipping company|shipping line|maritime|seaports?|port authority|shipyards?|shipbuilding|vessels?|container terminal|ports? of)\b/i],
  ['Poçt', /\b(postal|post office|mail carrier|parcel)\b/i],
  ['Telekom', /\b(telecom|telecommunications?|telco|mobile operator|internet service provider|isp|broadband|cellular|5g)\b/i],
  ['Logistika', /\b(logistics|freight|courier|supply chain|trucking|warehouse|cargo|delivery service|forwarding|transport company|transportation)\b/i],
];

const AZ_RE = /azerbaijan|azərbaycan|azerbaycan|\bbaku\b|\bbakı\b|\.az\b|\.gov\.az/i;

function esc(s) { return s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'); }

function makeClassifier(clients) {
  const compiled = clients.map((c) => ({
    name: c.name,
    res: (c.keywords || []).filter(Boolean).map((k) => new RegExp('(^|[^\\p{L}\\p{N}])' + esc(k.toLowerCase()) + '($|[^\\p{L}\\p{N}])', 'iu')),
  }));
  return function classify(text, opts = {}) {
    const t = String(text || '');
    let sector = null;
    for (const [name, re] of SECTOR_PATTERNS) if (re.test(t)) { sector = name; break; }
    const matched = compiled.filter((c) => c.res.some((re) => re.test(t))).map((c) => c.name);
    const az = AZ_RE.test(t) || opts.country === 'AZ';
    return { sector, matched_clients: matched, region_az: az };
  };
}

module.exports = { makeClassifier, SECTOR_PATTERNS };
