'use strict';
// Toplayıcı: mənbələri vaxtı çatdıqca və ya "İndi işlət" basılanda işə salır.
const { pool, migrate, waitForDb } = require('./db');

const COLLECTORS = {
  kev: require('./collectors/kev'),
  ransomware: require('./collectors/ransomware'),
  rss: require('./collectors/rss'),
  mitre: require('./collectors/mitre'),
};

async function runSource(s) {
  const started = Date.now();
  try {
    const n = await COLLECTORS[s.key].run(s.config);
    await pool.query("update sources set last_run = now(), last_status = 'ok', last_count = $2, last_error = null, run_requested = false where key = $1", [s.key, n]);
    console.log(`[${s.key}] ok: ${n} yeni qeyd (${Math.round((Date.now() - started) / 1000)} san)`);
  } catch (e) {
    await pool.query("update sources set last_run = now(), last_status = 'error', last_count = 0, last_error = $2, run_requested = false where key = $1", [s.key, String(e.message).slice(0, 500)]);
    console.error(`[${s.key}] xəta: ${e.message}`);
  }
}

async function tick() {
  const { rows } = await pool.query(
    `select * from sources where enabled and (run_requested or last_run is null or last_run < now() - (interval_min || ' minutes')::interval) order by last_run nulls first`);
  for (const s of rows) if (COLLECTORS[s.key]) await runSource(s);
}

(async () => {
  await waitForDb();
  await migrate();
  console.log('Toplayıcı işə düşdü.');
  for (;;) {
    try { await tick(); } catch (e) { console.error('tick xətası:', e.message); }
    await new Promise((r) => setTimeout(r, 20000));
  }
})();
