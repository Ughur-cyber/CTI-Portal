'use strict';
const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { pool, migrate, waitForDb } = require('./db');
const { upsertItems } = require('./items');

const PORT = Number(process.env.PORT || 8080);
const USER = process.env.DASH_USER || '';
const PASS = process.env.DASH_PASS || '';
const INGEST_KEY = process.env.INGEST_KEY || '';
const PUBLIC_DIR = path.join(__dirname, '..', 'public');

const safeEq = (a, b) => crypto.timingSafeEqual(crypto.createHash('sha256').update(String(a)).digest(), crypto.createHash('sha256').update(String(b)).digest());
function authorized(req) {
  if (!USER && !PASS) return true;
  const h = req.headers.authorization || '';
  if (!h.startsWith('Basic ')) return false;
  const [u, ...rest] = Buffer.from(h.slice(6), 'base64').toString('utf8').split(':');
  return safeEq(u, USER) && safeEq(rest.join(':'), PASS);
}

const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.woff2': 'font/woff2', '.svg': 'image/svg+xml', '.ico': 'image/x-icon' };
const SEC = {
  'X-Content-Type-Options': 'nosniff', 'X-Frame-Options': 'DENY', 'Referrer-Policy': 'no-referrer',
  'Content-Security-Policy': "default-src 'self'; img-src 'self' data:; style-src 'self' 'unsafe-inline'; script-src 'self'; connect-src 'self'; base-uri 'none'; form-action 'none'; frame-ancestors 'none'",
};
const send = (res, code, body, h = {}) => { res.writeHead(code, { ...SEC, ...h }); res.end(body); };
const json = (res, code, obj) => send(res, code, JSON.stringify(obj), { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
const readBody = (req, max = 5e6) => new Promise((resolve, reject) => {
  let b = ''; req.on('data', (d) => { b += d; if (b.length > max) { reject(new Error('Çox böyük sorğu')); req.destroy(); } }); req.on('end', () => resolve(b)); req.on('error', reject);
});

const TIER_SQL = `case when cardinality(matched_clients) > 0 then 1 when region_az then 2 when sector is not null then 3 else 4 end`;
const clampInt = (v, d, lo, hi) => { const n = parseInt(v, 10); return isNaN(n) ? d : Math.min(hi, Math.max(lo, n)); };
const ITEM_COLS = `id, kind, ext_id, title, summary, occurred_at, source, url, sector, severity, tags, matched_clients, region_az, data, ${TIER_SQL} as tier`;

async function overview() {
  const q = (s, p) => pool.query(s, p).then((r) => r.rows);
  const [counts, alerts, daily, sectors, totals, srcs] = await Promise.all([
    q(`select kind, count(*)::int total, count(*) filter (where occurred_at > now() - interval '1 day')::int d1, count(*) filter (where occurred_at > now() - interval '7 days')::int d7 from items group by kind`),
    q(`select ${ITEM_COLS} from items where occurred_at > now() - interval '30 days' and (${TIER_SQL}) < 4 and not (kind = 'news' and (${TIER_SQL}) = 3)
       order by (${TIER_SQL}), occurred_at desc limit 40`),
    q(`select to_char(date_trunc('day', occurred_at), 'YYYY-MM-DD') d, kind, count(*)::int n from items where occurred_at > now() - interval '30 days' group by 1, 2 order by 1`),
    q(`select coalesce(sector, 'Təyin olunmayıb') sector, count(*)::int n from items where kind = 'ransomware' and occurred_at > now() - interval '30 days' group by 1 order by 2 desc`),
    q(`select (select count(*) from actors)::int actors, (select count(*) from malware)::int malware, (select count(*) from clients)::int clients`),
    q(`select key, title, last_run, last_status from sources order by key`),
  ]);
  return { counts, alerts, daily, sectors, totals: totals[0], sources: srcs };
}

async function listItems(sp) {
  const where = []; const p = [];
  const add = (sql, v) => { p.push(v); where.push(sql.replace('$$', '$' + p.length)); };
  if (sp.get('kind')) add('kind = $$', sp.get('kind'));
  if (sp.get('sector')) add('sector = $$', sp.get('sector'));
  if (sp.get('severity')) add('severity = $$', sp.get('severity'));
  if (sp.get('client')) add('$$ = any(matched_clients)', sp.get('client'));
  if (sp.get('tier')) add(`(${TIER_SQL}) <= $$`, clampInt(sp.get('tier'), 4, 1, 4));
  if (sp.get('days')) add(`occurred_at > now() - ($$ || ' days')::interval`, String(clampInt(sp.get('days'), 30, 1, 3650)));
  if (sp.get('q')) { p.push('%' + sp.get('q').replace(/[%_\\]/g, '\\$&') + '%'); const n = '$' + p.length; where.push(`(title ilike ${n} or summary ilike ${n} or source ilike ${n})`); }
  const w = where.length ? 'where ' + where.join(' and ') : '';
  const limit = clampInt(sp.get('limit'), 50, 1, 200), offset = clampInt(sp.get('offset'), 0, 0, 1e6);
  const [rows, tot] = await Promise.all([
    pool.query(`select ${ITEM_COLS} from items ${w} order by occurred_at desc limit ${limit} offset ${offset}`, p),
    pool.query(`select count(*)::int n from items ${w}`, p),
  ]);
  return { rows: rows.rows, total: tot.rows[0].n };
}

async function route(req, res, url) {
  const p = url.pathname, sp = url.searchParams;
  if (req.method === 'POST' && p === '/api/ingest') {
    if (!INGEST_KEY || !safeEq(req.headers['x-api-key'] || '', INGEST_KEY)) return json(res, 401, { error: 'API açarı yanlışdır' });
    let body; try { body = JSON.parse(await readBody(req)); } catch (e) { return json(res, 400, { error: 'JSON düzgün deyil' }); }
    const list = (Array.isArray(body) ? body : [body]).filter((x) => x && x.kind && x.ext_id && x.title).slice(0, 2000);
    const inserted = await upsertItems(list.map((x) => ({ ...x, occurred_at: x.occurred_at ? new Date(x.occurred_at) : new Date(), extraText: x.extraText || '' })));
    return json(res, 200, { received: list.length, inserted });
  }
  if (req.method === 'POST') {
    const m = p.match(/^\/api\/sources\/(\w+)\/run$/);
    if (m) { await pool.query('update sources set run_requested = true where key = $1', [m[1]]); return json(res, 200, { ok: true }); }
    return json(res, 404, { error: 'Tapılmadı' });
  }
  if (req.method !== 'GET') return send(res, 405, 'Method not allowed');

  if (p === '/api/overview') return json(res, 200, await overview());
  if (p === '/api/items') return json(res, 200, await listItems(sp));
  if (p === '/api/actors') {
    const q = sp.get('q') ? '%' + sp.get('q').replace(/[%_\\]/g, '\\$&') + '%' : '%';
    const r = await pool.query(`select id, name, mitre_id, aliases, jsonb_array_length(techniques)::int tech, cardinality(software)::int soft, left(description, 220) short
      from actors where name ilike $1 or exists (select 1 from unnest(aliases) a where a ilike $1) order by name limit 400`, [q]);
    return json(res, 200, r.rows);
  }
  let m = p.match(/^\/api\/actors\/(\d+)$/);
  if (m) { const r = await pool.query('select * from actors where id = $1', [m[1]]); return r.rows[0] ? json(res, 200, r.rows[0]) : json(res, 404, { error: 'Tapılmadı' }); }
  if (p === '/api/malware') {
    const q = sp.get('q') ? '%' + sp.get('q').replace(/[%_\\]/g, '\\$&') + '%' : '%';
    const r = await pool.query(`select id, name, mitre_id, kind, aliases, cardinality(used_by)::int groups, left(description, 220) short
      from malware where name ilike $1 or exists (select 1 from unnest(aliases) a where a ilike $1) order by name limit 400`, [q]);
    return json(res, 200, r.rows);
  }
  m = p.match(/^\/api\/malware\/(\d+)$/);
  if (m) { const r = await pool.query('select * from malware where id = $1', [m[1]]); return r.rows[0] ? json(res, 200, r.rows[0]) : json(res, 404, { error: 'Tapılmadı' }); }
  if (p === '/api/clients') {
    const r = await pool.query(`select c.name, c.sector, c.keywords,
      (select count(*)::int from items i where c.name = any(i.matched_clients)) total,
      (select count(*)::int from items i where c.name = any(i.matched_clients) and i.occurred_at > now() - interval '30 days') d30
      from clients c order by c.name`);
    return json(res, 200, r.rows);
  }
  if (p === '/api/sources') {
    const r = await pool.query('select key, title, interval_min, enabled, last_run, last_status, last_count, last_error, run_requested from sources order by key');
    return json(res, 200, r.rows);
  }
  return json(res, 404, { error: 'Tapılmadı' });
}

const server = http.createServer(async (req, res) => {
  try {
    const url = new URL(req.url, 'http://x');
    if (url.pathname === '/healthz') return json(res, 200, { ok: true });
    if (!authorized(req)) return send(res, 401, 'Giriş tələb olunur', { 'WWW-Authenticate': 'Basic realm="CTI Portal", charset="UTF-8"', 'Content-Type': 'text/plain; charset=utf-8' });
    if (url.pathname.startsWith('/api/')) return await route(req, res, url);
    if (req.method !== 'GET') return send(res, 405, 'Method not allowed');
    const rel = url.pathname === '/' ? '/index.html' : decodeURIComponent(url.pathname);
    const file = path.normalize(path.join(PUBLIC_DIR, rel));
    if (!file.startsWith(PUBLIC_DIR)) return send(res, 403, 'Forbidden');
    fs.readFile(file, (err, data) => {
      if (err) return send(res, 404, 'Tapılmadı', { 'Content-Type': 'text/plain; charset=utf-8' });
      const ext = path.extname(file);
      send(res, 200, data, { 'Content-Type': MIME[ext] || 'application/octet-stream', 'Cache-Control': ext === '.woff2' ? 'public, max-age=31536000, immutable' : 'no-cache' });
    });
  } catch (e) {
    console.error(e);
    json(res, 500, { error: 'Server xətası: ' + e.message });
  }
});

(async () => {
  await waitForDb();
  await migrate();
  server.listen(PORT, () => {
    console.log('CTI Portal: http://localhost:' + PORT);
    if (!USER && !PASS) console.warn('Xəbərdarlıq: DASH_USER/DASH_PASS yoxdur, səhifə parolsuz açıqdır.');
    if (!INGEST_KEY) console.warn('Qeyd: INGEST_KEY yoxdur, n8n-dən məlumat qəbulu söndürülüb.');
  });
})();
