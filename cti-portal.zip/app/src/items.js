'use strict';
const { pool } = require('./db');
const { makeClassifier } = require('./classify');

let cache = { at: 0, fn: null };
async function classifier() {
  if (!cache.fn || Date.now() - cache.at > 60000) {
    const { rows } = await pool.query('select name, sector, keywords from clients');
    cache = { at: Date.now(), fn: makeClassifier(rows) };
  }
  return cache.fn;
}

// item: {kind, ext_id, title, summary, occurred_at, source, url, sector?, severity, tags, data, country?}
async function upsertItems(items) {
  if (!items.length) return 0;
  const classify = await classifier();
  const client = await pool.connect();
  let inserted = 0;
  try {
    await client.query('begin');
    for (const it of items) {
      const c = classify([it.title, it.summary, it.url, it.extraText].join(' \n '), { country: it.country });
      const sector = it.preferText ? (c.sector || it.sector) : (it.sector || c.sector);
      const r = await client.query(
        `insert into items(kind, ext_id, title, summary, occurred_at, source, url, sector, severity, tags, matched_clients, region_az, data)
         values ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13)
         on conflict (kind, ext_id) do update set title = excluded.title, summary = excluded.summary, sector = excluded.sector,
           severity = excluded.severity, tags = excluded.tags, matched_clients = excluded.matched_clients, region_az = excluded.region_az, data = excluded.data
         returning (xmax = 0) as inserted`,
        [it.kind, String(it.ext_id).slice(0, 300), String(it.title).slice(0, 500), it.summary ? String(it.summary).slice(0, 2000) : null,
          it.occurred_at || new Date(), it.source || null, it.url || null, sector || null, it.severity || 'info',
          it.tags || [], c.matched_clients, c.region_az, it.data || {}]);
      if (r.rows[0].inserted) inserted++;
    }
    await client.query('commit');
  } catch (e) {
    await client.query('rollback');
    throw e;
  } finally {
    client.release();
  }
  return inserted;
}

module.exports = { upsertItems };
