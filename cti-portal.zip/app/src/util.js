'use strict';
async function getJson(url, headers = {}, timeoutMs = 60000) {
  const res = await fetch(url, { headers: { 'User-Agent': 'cti-portal/0.1', Accept: 'application/json', ...headers }, signal: AbortSignal.timeout(timeoutMs) });
  if (!res.ok) throw new Error(url + ' -> HTTP ' + res.status);
  return res.json();
}
async function getText(url, headers = {}, timeoutMs = 60000) {
  const res = await fetch(url, { headers: { 'User-Agent': 'cti-portal/0.1', ...headers }, signal: AbortSignal.timeout(timeoutMs) });
  if (!res.ok) throw new Error(url + ' -> HTTP ' + res.status);
  return res.text();
}
const stripHtml = (s) => String(s || '').replace(/<[^>]*>/g, ' ').replace(/&nbsp;/g, ' ').replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"').replace(/&#0?39;/g, "'").replace(/\s+/g, ' ').trim();
const toDate = (v) => { const d = new Date(v); return isNaN(d) ? null : d; };
module.exports = { getJson, getText, stripHtml, toDate };
