'use strict';
const { getJson, toDate } = require('../util');
const { upsertItems } = require('../items');

const URLS = [
  'https://www.cisa.gov/sites/default/files/feeds/known_exploited_vulnerabilities.json',
  'https://raw.githubusercontent.com/cisagov/kev-data/main/known_exploited_vulnerabilities.json',
];

function map(v) {
  const nvd = 'https://nvd.nist.gov/vuln/detail/' + v.cveID;
  return {
    kind: 'kev',
    ext_id: v.cveID,
    title: `${v.cveID}: ${v.vulnerabilityName || v.product}`,
    summary: v.shortDescription,
    occurred_at: toDate(v.dateAdded) || new Date(),
    source: 'CISA KEV',
    url: nvd,
    severity: v.knownRansomwareCampaignUse === 'Known' ? 'critical' : 'high',
    tags: ['kev', v.vendorProject, v.product].filter(Boolean),
    extraText: `${v.vendorProject} ${v.product}`,
    data: { vendor: v.vendorProject, product: v.product, due: v.dueDate, action: v.requiredAction, ransomware: v.knownRansomwareCampaignUse, cwes: v.cwes || [] },
  };
}

async function run() {
  let json, last;
  for (const u of URLS) {
    try { json = await getJson(u); break; } catch (e) { last = e; }
  }
  if (!json) throw last;
  return upsertItems((json.vulnerabilities || []).map(map));
}
module.exports = { run, map };
