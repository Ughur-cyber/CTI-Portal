'use strict';
const crypto = require('crypto');
const { getJson, toDate, stripHtml } = require('../util');
const { upsertItems } = require('../items');

const URLS = ['https://api.ransomware.live/v2/recentvictims', 'https://api.ransomware.live/recentvictims'];

function sectorFromActivity(a) {
  const t = String(a || '').toLowerCase();
  if (/telecom/.test(t)) return 'Telekom';
  if (/transport|logistic|shipping|aviation|airline|maritime|railway/.test(t)) {
    if (/aviation|airline/.test(t)) return 'Aviasiya';
    if (/maritime|shipping/.test(t)) return 'Dəniz/Liman';
    if (/rail/.test(t)) return 'Dəmiryolu';
    return 'Logistika';
  }
  return null;
}

function map(v) {
  const name = v.victim || v.post_title || v.name || v.title;
  if (!name) return null;
  const group = v.group || v.group_name || 'unknown';
  const when = toDate(v.discovered || v.published || v.attackdate || v.date) || new Date();
  const country = v.country || '';
  const id = crypto.createHash('sha1').update(group + '|' + name + '|' + when.toISOString().slice(0, 10)).digest('hex').slice(0, 20);
  const desc = stripHtml(v.description || '');
  return {
    kind: 'ransomware',
    ext_id: id,
    title: `${name} (${group})`,
    summary: desc || `${group} qrupu ${name} təşkilatını qurban kimi elan edib.`,
    occurred_at: when,
    source: 'ransomware.live',
    url: v.permalink || v.url || v.claim_url || (v.website ? 'https://' + String(v.website).replace(/^https?:\/\//, '') : null),
    sector: sectorFromActivity(v.activity),
    preferText: true,
    severity: 'high',
    tags: ['ransomware', group, country].filter(Boolean),
    country,
    extraText: `${v.website || ''} ${v.domain || ''} ${v.activity || ''}`,
    data: { victim: name, group, country, activity: v.activity || null, website: v.website || v.domain || null, attackdate: v.attackdate || null },
  };
}

async function run() {
  const headers = process.env.RANSOMWARE_LIVE_KEY ? { 'X-API-KEY': process.env.RANSOMWARE_LIVE_KEY } : {};
  let json, last;
  for (const u of URLS) {
    try { json = await getJson(u, headers); break; } catch (e) { last = e; }
  }
  if (!json) throw last;
  const arr = Array.isArray(json) ? json : json.victims || json.data || [];
  return upsertItems(arr.map(map).filter(Boolean));
}
module.exports = { run, map, sectorFromActivity };
