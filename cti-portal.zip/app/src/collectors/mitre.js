'use strict';
const { pool } = require('../db');
const { getJson } = require('../util');

const URL = 'https://raw.githubusercontent.com/mitre/cti/master/enterprise-attack/enterprise-attack.json';
const clean = (t) => String(t || '').replace(/\(Citation:[^)]*\)/g, '').replace(/\[([^\]]+)\]\([^)]*\)/g, '$1').trim();
const mid = (o) => ((o.external_references || []).find((r) => r.source_name === 'mitre-attack') || {}).external_id || null;

function parse(bundle) {
  const objs = (bundle.objects || []).filter((o) => !o.revoked && !o.x_mitre_deprecated);
  const byId = new Map(objs.map((o) => [o.id, o]));
  const groups = objs.filter((o) => o.type === 'intrusion-set');
  const soft = objs.filter((o) => o.type === 'malware' || o.type === 'tool');
  const uses = objs.filter((o) => o.type === 'relationship' && o.relationship_type === 'uses');

  const actors = new Map(groups.map((g) => [g.id, {
    name: g.name, mitre_id: mid(g), aliases: (g.aliases || []).filter((a) => a !== g.name),
    description: clean(g.description), techniques: [], software: new Set(),
  }]));
  const malware = new Map(soft.map((s) => [s.id, {
    name: s.name, mitre_id: mid(s), kind: s.type, aliases: (s.x_mitre_aliases || []).filter((a) => a !== s.name),
    description: clean(s.description), used_by: new Set(), platforms: s.x_mitre_platforms || [],
  }]));

  for (const r of uses) {
    const a = actors.get(r.source_ref);
    if (!a) continue;
    const t = byId.get(r.target_ref);
    if (!t) continue;
    if (t.type === 'attack-pattern') {
      a.techniques.push({ id: mid(t), name: t.name, tactic: ((t.kill_chain_phases || [])[0] || {}).phase_name || null });
    } else if (malware.has(t.id)) {
      a.software.add(t.name);
      malware.get(t.id).used_by.add(a.name);
    }
  }
  return { actors: [...actors.values()].map((a) => ({ ...a, software: [...a.software] })), malware: [...malware.values()].map((m) => ({ ...m, used_by: [...m.used_by] })) };
}

async function run() {
  const bundle = await getJson(URL, {}, 180000);
  const { actors, malware } = parse(bundle);
  for (const a of actors) {
    await pool.query(
      `insert into actors(name, mitre_id, aliases, description, techniques, software, updated_at) values ($1,$2,$3,$4,$5,$6, now())
       on conflict (name) do update set mitre_id = excluded.mitre_id, aliases = excluded.aliases, description = excluded.description,
         techniques = excluded.techniques, software = excluded.software, updated_at = now()`,
      [a.name, a.mitre_id, a.aliases, a.description, JSON.stringify(a.techniques), a.software]);
  }
  for (const m of malware) {
    await pool.query(
      `insert into malware(name, mitre_id, kind, aliases, description, used_by, platforms, updated_at) values ($1,$2,$3,$4,$5,$6,$7, now())
       on conflict (name) do update set mitre_id = excluded.mitre_id, kind = excluded.kind, aliases = excluded.aliases, description = excluded.description,
         used_by = excluded.used_by, platforms = excluded.platforms, updated_at = now()`,
      [m.name, m.mitre_id, m.kind, m.aliases, m.description, m.used_by, m.platforms]);
  }
  return actors.length + malware.length;
}
module.exports = { run, parse };
