# CTI Portal

Öz CTI platformamız: CISA KEV, ransomware qurbanları, xəbər lentləri, MITRE ATT&CK qrupları və zərərli proqramlar bir yerdə.
Hadisələr müştəri adlarına, Azərbaycana və sektora görə avtomatik işarələnir.

## Hissələr
- `db`: PostgreSQL bazası
- `web`: veb panel, `http://SERVER:8080`
- `collector`: mənbələrdən məlumat toplayır (özü işləyir)
- `n8n`: avtomatlaşdırmalar, `http://SERVER:5678`

## Quraşdırma
1. `.env.example` faylını `.env` adı ilə köçür: `cp .env.example .env`
2. `nano .env` ilə 4 parolu dəyiş.
3. `docker compose up -d --build`
4. Brauzerdə `http://SERVER:8080` aç.

## Faydalı əmrlər
- Vəziyyət: `docker compose ps`
- Loglar: `docker compose logs -f collector`
- Yenidən başlat: `docker compose restart`
- Yenilə: `docker compose up -d --build`

## n8n-dən məlumat göndərmək (phishing, CVE)
`POST http://web:8080/api/ingest` (n8n eyni şəbəkədə olduğu üçün `web` adı işləyir), başlıq `x-api-key: <INGEST_KEY>`.
Gövdə (JSON siyahı): `kind` (phishing/cve), `ext_id`, `title`, `summary`, `occurred_at`, `source`, `url`, `sector`, `severity`, `tags`, `data`.
