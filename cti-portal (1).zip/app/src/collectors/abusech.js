'use strict';
const { getJson, toDate } = require('../util');
const { upsertItems } = require('../items');

function mapThreatFox(r) {
  return {
    kind: 'ioc',
    ext_id: `threatfox:${r.id}`,
    title: `${r.ioc} (${r.malware_printable || r.malware || r.threat_type})`,
    summary: `ThreatFox IOC. Növ: ${r.ioc_type || ''}. Təhlükə: ${r.threat_type || ''}. Etibar: ${r.confidence_level || '?'}%.`,
    occurred_at: toDate(String(r.first_seen || '').replace(' UTC', 'Z').replace(' ', 'T')) || new Date(),
    source: 'ThreatFox',
    url: `https://threatfox.abuse.ch/ioc/${r.id}/`,
    severity: Number(r.confidence_level) >= 75 ? 'high' : 'medium',
    tags: ['ioc', r.malware_printable, ...(r.tags || [])].filter(Boolean),
    data: { ioc: r.ioc, type: r.ioc_type, malware: r.malware_printable, confidence: r.confidence_level },
  };
}
function mapUrlhaus(r) {
  return {
    kind: 'ioc',
    ext_id: `urlhaus:${r.id}`,
    title: String(r.url).slice(0, 300),
    summary: `URLhaus: zərərli proqram yayan ünvan. Təhlükə: ${r.threat || ''}. Status: ${r.url_status || ''}.`,
    occurred_at: toDate(String(r.date_added || '').replace(' UTC', 'Z').replace(' ', 'T')) || new Date(),
    source: 'URLhaus',
    url: r.urlhaus_link,
    severity: 'high',
    tags: ['ioc', 'malware-url', ...(r.tags || [])].filter(Boolean),
    data: { host: r.host, status: r.url_status, threat: r.threat },
  };
}

async function run() {
  const key = process.env.ABUSECH_KEY;
  if (!key) return { count: 0, warning: 'ABUSECH_KEY təyin olunmayıb (.env faylına yazılmalıdır). Açar pulsuzdur: auth.abuse.ch' };
  const headers = { 'Auth-Key': key };
  let total = 0; const warns = [];
  try {
    const res = await fetch('https://threatfox-api.abuse.ch/api/v1/', { method: 'POST', headers: { ...headers, 'Content-Type': 'application/json' }, body: JSON.stringify({ query: 'get_iocs', days: 1 }), signal: AbortSignal.timeout(60000) });
    const j = await res.json();
    if (j.query_status !== 'ok') throw new Error('ThreatFox: ' + (j.data || j.query_status));
    total += await upsertItems((j.data || []).slice(0, 1500).map(mapThreatFox));
  } catch (e) { warns.push(e.message); }
  try {
    const j = await getJson('https://urlhaus-api.abuse.ch/v1/urls/recent/limit/500/', headers);
    total += await upsertItems((j.urls || []).map(mapUrlhaus));
  } catch (e) { warns.push('URLhaus: ' + e.message); }
  if (warns.length === 2) throw new Error(warns.join(' | '));
  return { count: total, warning: warns.join(' | ') || null };
}
module.exports = { run, mapThreatFox, mapUrlhaus };
