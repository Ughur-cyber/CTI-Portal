'use strict';
const crypto = require('crypto');
const { XMLParser } = require('fast-xml-parser');
const { getText, stripHtml, toDate } = require('../util');
const { upsertItems } = require('../items');

const parser = new XMLParser({ ignoreAttributes: false, attributeNamePrefix: '@_', textNodeName: '#text', processEntities: true });
const arr = (x) => (x == null ? [] : Array.isArray(x) ? x : [x]);
const txt = (x) => (x == null ? '' : typeof x === 'object' ? (x['#text'] || '') : String(x));

function parseFeed(xml, feedUrl) {
  const doc = parser.parse(xml);
  const out = [];
  if (doc.rss) {
    const ch = doc.rss.channel;
    const siteTitle = txt(ch.title);
    for (const it of arr(ch.item)) {
      const link = txt(it.link);
      out.push({ guid: txt(it.guid) || link, title: stripHtml(txt(it.title)), link, summary: stripHtml(txt(it.description) || txt(it['content:encoded'])).slice(0, 600), date: txt(it.pubDate) || txt(it['dc:date']), site: siteTitle });
    }
  } else if (doc.feed) {
    const siteTitle = txt(doc.feed.title);
    for (const it of arr(doc.feed.entry)) {
      const links = arr(it.link);
      const l = links.find((x) => x['@_rel'] === 'alternate') || links[0] || {};
      const link = l['@_href'] || '';
      out.push({ guid: txt(it.id) || link, title: stripHtml(txt(it.title)), link, summary: stripHtml(txt(it.summary) || txt(it.content)).slice(0, 600), date: txt(it.updated) || txt(it.published), site: siteTitle });
    }
  }
  return out.filter((x) => x.title && (x.guid || x.link));
}

function map(e) {
  return {
    kind: 'news',
    ext_id: crypto.createHash('sha1').update(e.guid || e.link).digest('hex').slice(0, 24),
    title: e.title,
    summary: e.summary,
    occurred_at: toDate(e.date) || new Date(),
    source: e.site,
    url: e.link,
    severity: 'info',
    tags: [],
    data: {},
  };
}

async function run(config) {
  const feeds = (config && config.feeds) || [];
  let total = 0; const errors = [];
  for (const f of feeds) {
    try {
      const xml = await getText(f, { Accept: 'application/rss+xml, application/atom+xml, application/xml, text/xml' }, 30000);
      total += await upsertItems(parseFeed(xml, f).slice(0, 60).map(map));
    } catch (e) { errors.push(f + ': ' + e.message); }
  }
  if (errors.length === feeds.length && feeds.length) throw new Error(errors.join(' | '));
  return { count: total, warning: errors.length ? `${errors.length} lent oxunmadı: ` + errors.map((e) => e.replace(/^https?:\/\//, '').split(':')[0]).join(', ') : null };
}
module.exports = { run, parseFeed, map };
