'use strict';
const { pool } = require('../db');
const { getJson } = require('../util');

const URL = 'https://raw.githubusercontent.com/MISP/misp-galaxy/main/clusters/threat-actor.json';
const TRANSPORT_RE = /transport|rail|aviation|aerospace|logistic|telecom|maritime|shipping|ports?\b|travel|airline/i;
const arr = (x) => (Array.isArray(x) ? x : x ? [x] : []);

function parse(galaxy) {
  return (galaxy.values || []).filter((v) => v.value).map((v) => {
    const m = v.meta || {};
    const cats = arr(m['cfr-target-category']);
    const victims = arr(m['cfr-suspected-victims']);
    return {
      name: String(v.value).trim(),
      aliases: [...new Set(arr(m.synonyms).map((x) => String(x).trim()).filter(Boolean))],
      description: (v.description || '').trim(),
      country: m.country || null,
      state_sponsor: m['cfr-suspected-state-sponsor'] || null,
      motivation: [...arr(m['cfr-type-of-incident']), ...(arr(m['cfr-type-of-incident']).length ? [] : arr(m.motive))].join(', ') || null,
      target_categories: cats,
      victims,
      refs: arr(m.refs).filter((r) => /^https?:\/\//.test(r)).slice(0, 12),
      targets_az: victims.some((x) => /azerbaijan/i.test(x)),
      sector_relevant: cats.some((c) => TRANSPORT_RE.test(c)),
    };
  });
}

async function run() {
  const actors = parse(await getJson(URL, {}, 120000));
  // Hər işləmədə MISP-dən gələn sahələri sıfırlayıb yenidən yığırıq (köhnə məlumat qalmasın)
  await pool.query(`update actors set targets_az = false, sector_relevant = false, victims = '{}', target_categories = '{}', refs = '{}', country = null, state_sponsor = null, motivation = null where 'misp' = any(sources)`);
  let touched = 0;
  for (const a of actors) {
    const exact = a.name.toLowerCase();
    // 1) ad və ya ləqəb tam üst-üstə düşür; 2) olmasa, MITRE adı MISP ləqəbləri arasındadır
    let hit = await pool.query(
      `select id, aliases from actors where lower(name) = $1 or exists (select 1 from unnest(aliases) al where lower(al) = $1) order by (lower(name) = $1) desc limit 1`, [exact]);
    if (!hit.rows[0] && a.aliases.length) {
      hit = await pool.query(`select id, aliases from actors where lower(name) = any($1) and mitre_id is not null limit 1`, [a.aliases.map((x) => x.toLowerCase())]);
    }
    if (hit.rows[0]) {
      const merged = [...new Set([...(hit.rows[0].aliases || []), a.name, ...a.aliases])];
      await pool.query(
        `update actors set aliases = $2, description = case when coalesce(description, '') = '' then $3 else description end,
           country = coalesce(country, $4), state_sponsor = coalesce(state_sponsor, $5), motivation = coalesce(motivation, $6),
           target_categories = (select coalesce(array_agg(distinct x), '{}') from unnest(target_categories || $7::text[]) x),
           victims = (select coalesce(array_agg(distinct x), '{}') from unnest(victims || $8::text[]) x),
           refs = (select coalesce(array_agg(distinct x), '{}') from unnest(refs || $9::text[]) x),
           sources = (select array_agg(distinct x) from unnest(sources || '{misp}'::text[]) x),
           targets_az = targets_az or $10, sector_relevant = sector_relevant or $11, updated_at = now()
         where id = $1`,
        [hit.rows[0].id, merged, a.description, a.country, a.state_sponsor, a.motivation, a.target_categories, a.victims, a.refs, a.targets_az, a.sector_relevant]);
    } else {
      await pool.query(
        `insert into actors(name, aliases, description, techniques, software, country, state_sponsor, motivation, target_categories, victims, refs, sources, targets_az, sector_relevant)
         values ($1,$2,$3,'[]','{}',$4,$5,$6,$7,$8,$9,'{misp}',$10,$11)
         on conflict (name) do update set country = excluded.country, state_sponsor = excluded.state_sponsor, motivation = excluded.motivation,
           target_categories = excluded.target_categories, victims = excluded.victims, refs = excluded.refs, targets_az = excluded.targets_az,
           sector_relevant = excluded.sector_relevant, sources = (select array_agg(distinct x) from unnest(actors.sources || '{misp}'::text[]) x), updated_at = now()`,
        [a.name, a.aliases, a.description, a.country, a.state_sponsor, a.motivation, a.target_categories, a.victims, a.refs, a.targets_az, a.sector_relevant]);
    }
    touched++;
  }
  return touched;
}
module.exports = { run, parse };
