'use strict';
const { getJson, toDate } = require('../util');
const { upsertItems } = require('../items');

const URL = 'https://feodotracker.abuse.ch/downloads/ipblocklist.json';

function map(r) {
  const ip = r.ip_address;
  if (!ip) return null;
  return {
    kind: 'ioc',
    ext_id: `feodo:${ip}:${r.port || 0}`,
    title: `${ip}:${r.port || '?'} (${r.malware || 'botnet'})`,
    summary: `Botnet C2 serveri. Zərərli proqram: ${r.malware || 'naməlum'}. Status: ${r.status || 'naməlum'}. Şəbəkə: ${r.as_name || ''} (${r.country || ''}).`,
    occurred_at: toDate(r.first_seen) || toDate(r.last_online) || new Date(),
    source: 'Feodo Tracker',
    url: `https://feodotracker.abuse.ch/browse/host/${ip}/`,
    severity: 'high',
    tags: ['ioc', 'c2', r.malware].filter(Boolean),
    data: { ip, port: r.port, malware: r.malware, status: r.status, as: r.as_name, country: r.country, last_online: r.last_online },
  };
}

async function run() {
  const json = await getJson(URL);
  const list = Array.isArray(json) ? json : json.blocklist || [];
  return upsertItems(list.map(map).filter(Boolean).slice(0, 2000));
}
module.exports = { run, map };
