'use strict';
const fs = require('fs');
const path = require('path');
const { Pool } = require('pg');

const pool = new Pool({ connectionString: process.env.DATABASE_URL, max: 8 });

const CLIENTS = [
  ['ADY', 'Dəmiryolu', ['azərbaycan dəmir yolları', 'azerbaijan railways', 'ady.az', 'ady railways']],
  ['ASCO', 'Dəniz', ['caspian shipping', 'asco.az', 'azerbaijan caspian shipping']],
  ['AZAL', 'Aviasiya', ['azal', 'azerbaijan airlines', 'azal.az']],
  ['AZCON Holding', 'Logistika', ['azcon']],
  ['Azerpost', 'Poçt', ['azerpost', 'azərpoçt', 'azerpost.az']],
  ['Azintelecom', 'Telekom', ['azintelecom', 'aztelekom']],
  ['Baku Metro', 'Metro', ['baku metro', 'bakı metropoliteni', 'metro.gov.az']],
  ['Baku Shipyard', 'Dəniz', ['baku shipyard', 'bakı gəmi', 'bakushipyard']],
  ['Baku Bus', 'Avtobus', ['baku bus', 'bakubus', 'bakı nəqliyyat agentliyi']],
  ['Baku Taxi', 'Taksi', ['baku taxi', 'bakutaxi']],
  ['Odero', 'Dəniz', ['odero shipyard', 'odero.az', 'odero group']],
  ['Port of Baku', 'Liman', ['port of baku', 'baku sea port', 'bakuport', 'baku international sea trade port', 'alat port']],
  ['Silk Way', 'Aviasiya', ['silk way', 'silkway']],
];

const FEEDS = [
  'https://www.bleepingcomputer.com/feed/',
  'https://feeds.feedburner.com/TheHackersNews',
  'https://www.cisa.gov/cybersecurity-advisories/all.xml',
  'https://blog.talosintelligence.com/rss/',
  'https://www.microsoft.com/en-us/security/blog/feed/',
  'https://unit42.paloaltonetworks.com/feed/',
  'https://www.securityweek.com/feed/',
  'https://thedfirreport.com/feed/',
  'https://securelist.com/feed/',
  'https://cloud.google.com/blog/topics/threat-intelligence/rss/',
  'https://www.welivesecurity.com/en/feed/',
  'https://therecord.media/feed',
  'https://www.sentinelone.com/labs/feed/',
  'https://research.checkpoint.com/feed/',
  'https://krebsonsecurity.com/feed/',
  'https://isc.sans.edu/rssfeed_full.xml',
  'https://www.darkreading.com/rss.xml',
];

async function migrate() {
  await pool.query(fs.readFileSync(path.join(__dirname, 'schema.sql'), 'utf8'));
  for (const [name, sector, kw] of CLIENTS) {
    await pool.query('insert into clients(name, sector, keywords) values ($1,$2,$3) on conflict (name) do nothing', [name, sector, kw]);
  }
  const src = [
    ['kev', 'CISA KEV (aktiv istismar olunan zəifliklər)', 180, {}],
    ['ransomware', 'Ransomware qurbanları (ransomware.live)', 60, {}],
    ['rss', 'Xəbər və hesabat lentləri (RSS)', 30, { feeds: FEEDS }],
    ['mitre', 'MITRE ATT&CK (qruplar və zərərli proqramlar)', 1440, {}],
    ['misp', 'MISP Galaxy (təhdid qrupları: ölkə, hədəflər)', 1440, {}],
    ['feodo', 'Feodo Tracker (botnet C2 IP-ləri)', 360, {}],
    ['abusech', 'abuse.ch ThreatFox və URLhaus (açar tələb edir)', 60, {}],
  ];
  for (const [key, title, interval, config] of src) {
    await pool.query('insert into sources(key, title, interval_min, config) values ($1,$2,$3,$4) on conflict (key) do nothing', [key, title, interval, config]);
  }
  // Yeni RSS lentləri köhnə quraşdırmalara da əlavə olunsun
  await pool.query(
    `update sources set config = jsonb_set(config, '{feeds}', (select jsonb_agg(distinct f) from (select jsonb_array_elements_text(coalesce(config->'feeds','[]'::jsonb)) f union select unnest($1::text[])) x)) where key = 'rss'`,
    [FEEDS]);
}

async function waitForDb(tries = 30) {
  for (let i = 0; i < tries; i++) {
    try { await pool.query('select 1'); return; } catch (e) { await new Promise((r) => setTimeout(r, 2000)); }
  }
  throw new Error('Baza ilə əlaqə qurulmadı (DATABASE_URL yoxlayın).');
}

module.exports = { pool, migrate, waitForDb };
